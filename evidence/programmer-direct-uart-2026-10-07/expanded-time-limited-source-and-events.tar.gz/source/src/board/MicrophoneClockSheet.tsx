import { ComponentNotes } from "./ComponentNotes"
import { groundPath } from "./GroundPaths"
import { place } from "./placement"
import { A_74LVC2G07GW_125 } from "../../imports/A_74LVC2G07GW_125"
import { TPS7A2028PDBVR } from "../../imports/TPS7A2028PDBVR/TPS7A2028PDBVR"
import { GRM188R61A106ME69D } from "../../imports/GRM188R61A106ME69D/GRM188R61A106ME69D"
import { GRM188R71C104KA01D } from "../../imports/GRM188R71C104KA01D/GRM188R71C104KA01D"
import { RC0603FR_07330RL } from "../../imports/RC0603FR_07330RL"
import { A_0603WAF1000T5E } from "../../imports/A_0603WAF1000T5E/A_0603WAF1000T5E"
import { RC0603FR_0710KL } from "../../imports/RC0603FR_0710KL/RC0603FR_0710KL"
import { RC0603FR_07100KL } from "../../imports/RC0603FR_07100KL/RC0603FR_07100KL"
import { A_0603WAF1001T5E } from "../../imports/A_0603WAF1001T5E/A_0603WAF1001T5E"

export function MicrophoneClockSheet({ placementOnly = false }: { placementOnly?: boolean } = {}) {
  return (
    <schematicsheet
      name="mic-regulated-clock-review"
      displayName="AI Remote A1 - Microphone power and clocks"
      sheetIndex={7}
      sheetSize="A4"
    >
      <group name="mic-regulated-clock-review-group" schLayout={{ layoutMode: "relative" }}>
        <TPS7A2028PDBVR name="U23" {...place("U23")} schX={-7.5} schY={6.75} />
        <A_74LVC2G07GW_125 name="U24" {...place("U24")} schX={3.75} schY={6.75} />
        <GRM188R61A106ME69D
          name="C73"
          {...place("C73")}
          schX={-11.25}
          schY={3.0}
          schRotation={-90}
        />
        <GRM188R61A106ME69D name="C74" {...place("C74")} schX={-7.5} schY={3.0} schRotation={-90} />
        <GRM188R71C104KA01D name="C75" {...place("C75")} schX={-6} schY={3.0} schRotation={-90} />
        <A_0603WAF1001T5E name="R86" {...place("R86")} schX={-3.75} schY={3.0} schRotation={-90} />
        <RC0603FR_07100KL
          name="R87"
          {...place("R87")}
          schX={-11.25}
          schY={6.75}
          schRotation={-90}
        />
        <A_0603WAF1000T5E name="R88" {...place("R88")} schX={0.0} schY={3.0} />
        <A_0603WAF1000T5E name="R89" {...place("R89")} schX={3.75} schY={3.0} />
        <RC0603FR_0710KL name="R90" {...place("R90")} schX={7.5} schY={3.0} schRotation={-90} />
        <RC0603FR_0710KL name="R91" {...place("R91")} schX={11.25} schY={3.0} schRotation={-90} />
        <RC0603FR_07330RL name="R92" {...place("R92")} schX={0.0} schY={-1.5} schRotation={-90} />
        <RC0603FR_07330RL name="R93" {...place("R93")} schX={3.75} schY={-1.5} schRotation={-90} />
        <RC0603FR_0710KL name="R94" {...place("R94")} schX={7.5} schY={-1.5} schRotation={-90} />
        <RC0603FR_0710KL name="R95" {...place("R95")} schX={11.25} schY={-1.5} schRotation={-90} />
        <trace from="U23.pin1" to="net.MIC_INPUT" />
        <trace
          from="U23.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U23.pin2", placementOnly)}
        />
        <trace from="U23.pin3" to="net.HOLD_HARDWARE" />
        <trace from="U23.pin5" to="net.VMIC" />
        <trace from="U24.pin1" to="net.MIC_BCLK_INPUT" />
        <trace
          from="U24.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U24.pin2", placementOnly)}
        />
        <trace from="U24.pin3" to="net.MIC_WS_INPUT" />
        <trace from="U24.pin4" to="net.MIC_WS" />
        <trace from="U24.pin5" to="net.VMIC" />
        <trace from="U24.pin6" to="net.MIC_BCLK" />
        <trace from="C73.pin1" to="net.MIC_INPUT" />
        <trace
          from="C73.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C73.pin2", placementOnly)}
        />
        <trace from="C74.pin1" to="net.VMIC" />
        <trace
          from="C74.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C74.pin2", placementOnly)}
        />
        <trace from="C75.pin1" to="net.VMIC" />
        <trace
          from="C75.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C75.pin2", placementOnly)}
        />
        <trace from="R86.pin1" to="net.VMIC" />
        <trace
          from="R86.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R86.pin2", placementOnly)}
        />
        <trace from="R87.pin1" to="net.HOLD_HARDWARE" />
        <trace
          from="R87.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R87.pin2", placementOnly)}
        />
        <trace from="R88.pin1" to="net.MCU_MIC_BCLK" />
        <trace from="R88.pin2" to="net.MIC_BCLK_INPUT" />
        <trace from="R89.pin1" to="net.MCU_MIC_WS" />
        <trace from="R89.pin2" to="net.MIC_WS_INPUT" />
        <trace from="R90.pin1" to="net.MIC_BCLK_INPUT" />
        <trace
          from="R90.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R90.pin2", placementOnly)}
        />
        <trace from="R91.pin1" to="net.MIC_WS_INPUT" />
        <trace
          from="R91.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R91.pin2", placementOnly)}
        />
        <trace from="R92.pin1" to="net.VMIC" />
        <trace from="R92.pin2" to="net.MIC_BCLK" />
        <trace from="R93.pin1" to="net.VMIC" />
        <trace from="R93.pin2" to="net.MIC_WS" />
        <trace from="R94.pin1" to="net.MIC_BCLK" />
        <trace
          from="R94.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R94.pin2", placementOnly)}
        />
        <trace from="R95.pin1" to="net.MIC_WS" />
        <trace
          from="R95.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R95.pin2", placementOnly)}
        />
      </group>
      <ComponentNotes sheet="mic-regulated-clock-review" />
    </schematicsheet>
  )
}
