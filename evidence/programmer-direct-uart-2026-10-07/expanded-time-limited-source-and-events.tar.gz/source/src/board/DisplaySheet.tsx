import { ComponentNotes } from "./ComponentNotes"
import { groundPath } from "./GroundPaths"
import { place } from "./placement"
import { TPS7A2028PDBVR } from "../../imports/TPS7A2028PDBVR/TPS7A2028PDBVR"
import { SN74LVC245APWR } from "../../imports/SN74LVC245APWR/SN74LVC245APWR"
import { AFC07_S50ECA_00 } from "../../imports/AFC07_S50ECA_00/AFC07_S50ECA_00"
import { RC0603FR_07100KL } from "../../imports/RC0603FR_07100KL/RC0603FR_07100KL"
import { RC0603FR_0710KL } from "../../imports/RC0603FR_0710KL/RC0603FR_0710KL"
import { A_0603WAF1001T5E } from "../../imports/A_0603WAF1001T5E/A_0603WAF1001T5E"
import { GRM188R61A106ME69D } from "../../imports/GRM188R61A106ME69D/GRM188R61A106ME69D"
import { GRM188R61A226ME15D } from "../../imports/GRM188R61A226ME15D/GRM188R61A226ME15D"
import { GRM188R71C104KA01D } from "../../imports/GRM188R71C104KA01D/GRM188R71C104KA01D"

export function DisplaySheet({ placementOnly = false }: { placementOnly?: boolean } = {}) {
  return (
    <schematicsheet
      name="display-logic-review"
      displayName="AI Remote A4 - PROVISIONAL BuyDisplay ER-TFT026-1 SPI II"
      sheetIndex={4}
      sheetSize="A4"
    >
      <group name="display-logic-review-group" schLayout={{ layoutMode: "relative" }}>
        <TPS7A2028PDBVR name="U13" {...place("U13")} schX={-6.75} schY={6.0} />
        <SN74LVC245APWR name="U14" {...place("U14")} schX={0.0} schY={0.0} />
        <AFC07_S50ECA_00 name="J7" {...place("J7")} schX={6.75} schY={0.0} />
        <GRM188R61A106ME69D
          name="C40"
          {...place("C40")}
          schX={-11.25}
          schY={6.0}
          schRotation={-90}
        />
        <GRM188R61A226ME15D name="C41" {...place("C41")} schX={-3.0} schY={6.0} schRotation={-90} />
        <GRM188R71C104KA01D
          name="C42"
          {...place("C42")}
          schX={-0.75}
          schY={6.0}
          schRotation={-90}
        />
        <GRM188R71C104KA01D
          name="C43"
          {...place("C43")}
          schX={-3.0}
          schY={8.25}
          schRotation={-90}
        />
        <RC0603FR_07100KL name="R40" {...place("R40")} schX={-6.75} schY={3.0} schRotation={-90} />
        <A_0603WAF1001T5E name="R41" {...place("R41")} schX={-3.0} schY={-6.75} schRotation={-90} />
        <trace from="U13.pin1" to="net.V3V3" />
        <trace
          from="U13.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U13.pin2", placementOnly)}
        />
        <trace from="U13.pin3" to="net.LCD_ENABLE" />
        <trace from="U13.pin5" to="net.VLCD" />
        <trace from="R40.pin1" to="net.LCD_ENABLE" />
        <trace
          from="R40.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R40.pin2", placementOnly)}
        />
        <trace from="R41.pin1" to="net.VLCD" />
        <trace
          from="R41.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R41.pin2", placementOnly)}
        />
        <trace from="C40.pin1" to="net.V3V3" />
        <trace
          from="C40.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C40.pin2", placementOnly)}
        />
        <trace from="C41.pin1" to="net.VLCD" />
        <trace
          from="C41.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C41.pin2", placementOnly)}
        />
        <trace from="C42.pin1" to="net.VLCD" />
        <trace
          from="C42.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C42.pin2", placementOnly)}
        />
        <trace from="C43.pin1" to="net.VLCD" />
        <trace
          from="C43.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C43.pin2", placementOnly)}
        />
        <trace from="U14.pin1" to="net.VLCD" />
        <trace
          from="U14.pin10"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U14.pin10", placementOnly)}
        />
        <trace
          from="U14.pin19"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U14.pin19", placementOnly)}
        />
        <trace from="U14.pin20" to="net.VLCD" />
        <trace
          from="U14.pin7"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U14.pin7", placementOnly)}
        />
        <trace
          from="U14.pin8"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U14.pin8", placementOnly)}
        />
        <trace
          from="U14.pin9"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U14.pin9", placementOnly)}
        />
        {/* BuyDisplay no-touch panel: SPI II IM[3:0]=1110; existing panel n to connector 51-n is PROVISIONAL; new portrait flex/contact orientation must be confirmed before routing. */}
        <trace from="J7.pin50" to="net.LCD_BACKLIGHT_OUTPUT" />
        <trace from="J7.pin49" to="net.LCD_BACKLIGHT_RETURN_1" />
        <trace from="J7.pin48" to="net.LCD_BACKLIGHT_RETURN_2" />
        <trace from="J7.pin47" to="net.LCD_BACKLIGHT_RETURN_3" />
        <trace from="J7.pin46" to="net.LCD_BACKLIGHT_RETURN_4" />
        <trace from="J7.pin45" to="net.GND" />
        <trace from="J7.pin44" to="net.VLCD" />
        <trace from="J7.pin43" to="net.VLCD" />
        <trace from="J7.pin42" to="net.VLCD" />
        <trace from="J7.pin41" to="net.LCD_RESET_N" />
        <trace from="J7.pin40" to="net.GND" />
        <trace from="J7.pin39" to="net.GND" />
        <trace from="J7.pin38" to="net.GND" />
        <trace from="J7.pin37" to="net.GND" />
        <trace from="J7.pin36" to="net.GND" />
        <trace from="J7.pin35" to="net.GND" />
        <trace from="J7.pin34" to="net.GND" />
        <trace from="J7.pin33" to="net.GND" />
        <trace from="J7.pin32" to="net.GND" />
        <trace from="J7.pin31" to="net.GND" />
        <trace from="J7.pin30" to="net.GND" />
        <trace from="J7.pin29" to="net.GND" />
        <trace from="J7.pin28" to="net.GND" />
        <trace from="J7.pin27" to="net.GND" />
        <trace from="J7.pin26" to="net.GND" />
        <trace from="J7.pin25" to="net.GND" />
        <trace from="J7.pin24" to="net.GND" />
        <trace from="J7.pin23" to="net.GND" />
        <trace from="J7.pin22" to="net.GND" />
        <trace from="J7.pin21" to="net.GND" />
        <trace from="J7.pin20" to="net.GND" />
        <trace from="J7.pin19" to="net.GND" />
        <trace from="J7.pin17" to="net.LCD_SDA" />
        <trace from="J7.pin16" to="net.VLCD" />
        <trace from="J7.pin15" to="net.LCD_DC" />
        <trace from="J7.pin14" to="net.LCD_SCLK" />
        <trace from="J7.pin13" to="net.LCD_CS_N" />
        <trace from="J7.pin11" to="net.VLCD" />
        <trace from="J7.pin10" to="net.VLCD" />
        <trace from="J7.pin9" to="net.VLCD" />
        <trace from="J7.pin8" to="net.GND" />
        <trace from="J7.pin3" to="net.GND" />
        <trace from="J7.pin2" to="net.GND" />
        <trace from="J7.pin1" to="net.GND" />
        <trace from="J7.pin51" to="net.GND" />
        <trace from="J7.pin52" to="net.GND" />
        {/* Panel SDO33, TE39, absent touch44-47 remain open. */}
        <RC0603FR_07100KL name="R47" {...place("R47")} schX={-6.0} schY={0.75} schRotation={-90} />
        <RC0603FR_0710KL name="R42" {...place("R42")} schX={11.25} schY={0.75} schRotation={-90} />
        <trace from="U14.pin2" to="net.MCU_LCD_CS_N" />
        <trace from="R47.pin1" to="net.MCU_LCD_CS_N" />
        <trace
          from="R47.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R47.pin2", placementOnly)}
        />
        <trace from="U14.pin18" to="net.LCD_CS_N" />
        <trace from="R42.pin1" to="net.LCD_CS_N" />
        <trace from="R42.pin2" to="net.VLCD" />
        <RC0603FR_07100KL name="R48" {...place("R48")} schX={-6.0} schY={-1.5} schRotation={-90} />
        <RC0603FR_0710KL name="R43" {...place("R43")} schX={11.25} schY={-1.5} schRotation={-90} />
        <trace from="U14.pin3" to="net.MCU_LCD_RESET_N" />
        <trace from="R48.pin1" to="net.MCU_LCD_RESET_N" />
        <trace
          from="R48.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R48.pin2", placementOnly)}
        />
        <trace from="U14.pin17" to="net.LCD_RESET_N" />
        <trace from="R43.pin1" to="net.LCD_RESET_N" />
        <trace
          from="R43.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R43.pin2", placementOnly)}
        />
        <RC0603FR_07100KL name="R49" {...place("R49")} schX={-6.0} schY={-3.75} schRotation={-90} />
        <RC0603FR_0710KL name="R44" {...place("R44")} schX={11.25} schY={-3.75} schRotation={-90} />
        <trace from="U14.pin4" to="net.MCU_LCD_DC" />
        <trace from="R49.pin1" to="net.MCU_LCD_DC" />
        <trace
          from="R49.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R49.pin2", placementOnly)}
        />
        <trace from="U14.pin16" to="net.LCD_DC" />
        <trace from="R44.pin1" to="net.LCD_DC" />
        <trace
          from="R44.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R44.pin2", placementOnly)}
        />
        <RC0603FR_07100KL name="R50" {...place("R50")} schX={-6.0} schY={-6.0} schRotation={-90} />
        <RC0603FR_0710KL name="R45" {...place("R45")} schX={11.25} schY={-6.0} schRotation={-90} />
        <trace from="U14.pin5" to="net.MCU_LCD_SCLK" />
        <trace from="R50.pin1" to="net.MCU_LCD_SCLK" />
        <trace
          from="R50.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R50.pin2", placementOnly)}
        />
        <trace from="U14.pin15" to="net.LCD_SCLK" />
        <trace from="R45.pin1" to="net.LCD_SCLK" />
        <trace
          from="R45.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R45.pin2", placementOnly)}
        />
        <RC0603FR_07100KL name="R51" {...place("R51")} schX={-6.0} schY={-8.25} schRotation={-90} />
        <RC0603FR_0710KL name="R46" {...place("R46")} schX={11.25} schY={-8.25} schRotation={-90} />
        <trace from="U14.pin6" to="net.MCU_LCD_SDA" />
        <trace from="R51.pin1" to="net.MCU_LCD_SDA" />
        <trace
          from="R51.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R51.pin2", placementOnly)}
        />
        <trace from="U14.pin14" to="net.LCD_SDA" />
        <trace from="R46.pin1" to="net.LCD_SDA" />
        <trace
          from="R46.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R46.pin2", placementOnly)}
        />
      </group>
      <ComponentNotes sheet="display-logic-review" />
    </schematicsheet>
  )
}
