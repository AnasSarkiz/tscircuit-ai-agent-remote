import { ComponentNotes } from "./ComponentNotes"
import { groundPath } from "./GroundPaths"
import { place } from "./placement"
import { TPS7A2030PDBVR } from "../../imports/TPS7A2030PDBVR"
import { AO3400A } from "../../imports/AO3400A/AO3400A"
import { SS14 } from "../../imports/SS14"
import { A_0603WAF1001T5E } from "../../imports/A_0603WAF1001T5E/A_0603WAF1001T5E"
import { RC0603FR_0710KL } from "../../imports/RC0603FR_0710KL/RC0603FR_0710KL"
import { RC0603FR_07100KL } from "../../imports/RC0603FR_07100KL/RC0603FR_07100KL"
import { A_0603WAF1000T5E } from "../../imports/A_0603WAF1000T5E/A_0603WAF1000T5E"
import { GRM188R61A106ME69D } from "../../imports/GRM188R61A106ME69D/GRM188R61A106ME69D"
import { GRM188R61A226ME15D } from "../../imports/GRM188R61A226ME15D/GRM188R61A226ME15D"
import { GRM188R71C104KA01D } from "../../imports/GRM188R71C104KA01D/GRM188R71C104KA01D"

export function HapticSheet({ placementOnly = false }: { placementOnly?: boolean } = {}) {
  return (
    <schematicsheet
      name="haptic-driver-review"
      displayName="AI Remote A1 - External motor and flyback"
      sheetIndex={6}
      sheetSize="A4"
    >
      <group name="haptic-driver-review-group" schLayout={{ layoutMode: "relative" }}>
        <TPS7A2030PDBVR name="U22" {...place("U22")} schX={-6} schY={2} />
        <AO3400A name="Q9" {...place("Q9")} schX={6} schY={-2} />
        <SS14 name="D3" {...place("D3")} schX={11} schY={2} schRotation={90} />
        <GRM188R61A106ME69D name="C70" {...place("C70")} schX={-11} schY={2} schRotation={-90} />
        <GRM188R61A226ME15D name="C71" {...place("C71")} schX={0} schY={2} schRotation={-90} />
        <GRM188R71C104KA01D name="C72" {...place("C72")} schX={15} schY={2} schRotation={-90} />
        <A_0603WAF1001T5E name="R82" {...place("R82")} schX={3} schY={2} schRotation={-90} />
        <A_0603WAF1000T5E name="R83" {...place("R83")} schX={1} schY={-6} />
        <RC0603FR_0710KL name="R84" {...place("R84")} schX={6} schY={-6} schRotation={-90} />
        <RC0603FR_07100KL name="R85" {...place("R85")} schX={-6} schY={-6} schRotation={-90} />
        <trace from="U22.pin1" to="net.VSYS" />
        <trace
          from="U22.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U22.pin2", placementOnly)}
        />
        <trace from="U22.pin3" to="net.MCU_HAPTIC_ENABLE" />
        <trace from="U22.pin5" to="net.VMOTOR" />
        <trace from="Q9.pin1" to="net.HAPTIC_NMOS_GATE" />
        <trace
          from="Q9.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("Q9.pin2", placementOnly)}
        />
        <trace from="Q9.pin3" to="net.HAPTIC_N" />
        <trace from="D3.pin1" to="net.VMOTOR" />
        <trace from="D3.pin2" to="net.HAPTIC_N" />
        <trace from="C70.pin1" to="net.VSYS" />
        <trace
          from="C70.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C70.pin2", placementOnly)}
        />
        <trace from="C71.pin1" to="net.VMOTOR" />
        <trace
          from="C71.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C71.pin2", placementOnly)}
        />
        <trace from="C72.pin1" to="net.VMOTOR" />
        <trace from="C72.pin2" to="net.HAPTIC_N" />
        <trace from="R82.pin1" to="net.VMOTOR" />
        <trace
          from="R82.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R82.pin2", placementOnly)}
        />
        <trace from="R83.pin1" to="net.MCU_HAPTIC_ENABLE" />
        <trace from="R83.pin2" to="net.HAPTIC_NMOS_GATE" />
        <trace from="R84.pin1" to="net.HAPTIC_NMOS_GATE" />
        <trace
          from="R84.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R84.pin2", placementOnly)}
        />
        <trace from="R85.pin1" to="net.MCU_HAPTIC_ENABLE" />
        <trace
          from="R85.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R85.pin2", placementOnly)}
        />
      </group>
      <ComponentNotes sheet="haptic-driver-review" />
    </schematicsheet>
  )
}
