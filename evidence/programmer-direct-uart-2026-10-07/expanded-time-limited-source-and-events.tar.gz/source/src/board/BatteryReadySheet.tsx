import { ComponentNotes } from "./ComponentNotes"
import { groundPath } from "./GroundPaths"
import { place } from "./placement"
import { TPS3808G33DBVR } from "../../imports/TPS3808G33DBVR/TPS3808G33DBVR"
import { RC0603FR_07470KL } from "../../imports/RC0603FR_07470KL/RC0603FR_07470KL"
import { GRM188R71C104KA01D } from "../../imports/GRM188R71C104KA01D/GRM188R71C104KA01D"

export function BatteryReadySheet({ placementOnly = false }: { placementOnly?: boolean } = {}) {
  return (
    <schematicsheet
      name="battery-ready-review"
      displayName="AI Remote A1 - Battery readiness - PROVISIONAL"
      sheetIndex={9}
      sheetSize="A4"
    >
      <group name="battery-ready-review-group" schLayout={{ layoutMode: "relative" }}>
        <TPS3808G33DBVR name="U25" {...place("U25")} schX={0} schY={4} />
        <RC0603FR_07470KL name="R96" {...place("R96")} schX={5} schY={4} schRotation={-90} />
        <RC0603FR_07470KL name="R97" {...place("R97")} schX={5} schY={-2} schRotation={-90} />
        <GRM188R71C104KA01D name="C76" {...place("C76")} schX={-5} schY={4} schRotation={-90} />
        <GRM188R71C104KA01D name="C77" {...place("C77")} schX={0} schY={-2} schRotation={-90} />
        <trace from="U25.pin1" to="net.BUCK_ENABLE" />
        <trace
          from="U25.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U25.pin2", placementOnly)}
        />
        <trace from="U25.pin3" to="net.VSYS" />
        <trace from="U25.pin5" to="net.PACK_BAT" />
        <trace from="U25.pin6" to="net.VSYS" />
        <trace from="R96.pin1" to="net.VSYS" />
        <trace from="R96.pin2" to="net.BUCK_ENABLE" />
        <trace from="R97.pin1" to="net.BUCK_ENABLE" />
        <trace
          from="R97.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R97.pin2", placementOnly)}
        />
        <trace from="C76.pin1" to="net.VSYS" />
        <trace
          from="C76.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C76.pin2", placementOnly)}
        />
        <trace from="C77.pin1" to="net.BUCK_ENABLE" />
        <trace
          from="C77.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C77.pin2", placementOnly)}
        />
      </group>
      <ComponentNotes sheet="battery-ready-review" />
    </schematicsheet>
  )
}
