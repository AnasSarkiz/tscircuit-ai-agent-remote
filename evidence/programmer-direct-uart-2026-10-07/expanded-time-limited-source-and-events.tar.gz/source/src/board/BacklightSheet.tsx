import { ComponentNotes } from "./ComponentNotes"
import { groundPath } from "./GroundPaths"
import { TPS60230RGTR } from "../../imports/TPS60230RGTR/TPS60230RGTR"
import { A_0603WAF1000T5E } from "../../imports/A_0603WAF1000T5E/A_0603WAF1000T5E"
import { RC0603FR_0710KL } from "../../imports/RC0603FR_0710KL/RC0603FR_0710KL"
import { CL10A105KB8NNNC } from "../../imports/CL10A105KB8NNNC/CL10A105KB8NNNC"
import { GRM188R61A106ME69D } from "../../imports/GRM188R61A106ME69D/GRM188R61A106ME69D"
import { place } from "./placement"

export function BacklightSheet({ placementOnly = false }: { placementOnly?: boolean } = {}) {
  return (
    <schematicsheet
      name="BacklightSheet"
      displayName="AI Remote A4 - Four-channel provisional display backlight"
      sheetSize="A4"
      sheetIndex={12}
    >
      <group name="BacklightSheet-group" schLayout={{ layoutMode: "relative" }}>
        <TPS60230RGTR name="U27" {...place("U27")} schX={0} schY={0} />
        <RC0603FR_0710KL name="R102" {...place("R102")} schX={-6} schY={-6} schRotation={-90} />
        <A_0603WAF1000T5E name="R103" {...place("R103")} schX={-9} schY={4} />
        <RC0603FR_0710KL name="R104" {...place("R104")} schX={-6} schY={1} schRotation={-90} />
        <CL10A105KB8NNNC name="C82" {...place("C82")} schX={8} schY={4} schOrientation="vertical" />
        <CL10A105KB8NNNC name="C83" {...place("C83")} schX={8} schY={1} schOrientation="vertical" />
        <GRM188R61A106ME69D name="C84" {...place("C84")} schX={-9} schY={-3} schRotation={-90} />
        <GRM188R61A106ME69D name="C85" {...place("C85")} schX={8} schY={-5} schRotation={-90} />
        <trace
          name="BL_CURRENT_SETTING"
          from="U27.pin1"
          to="R102.pin1"
          routingPhaseIndex={placementOnly ? undefined : 7}
        />
        <trace
          from="R102.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R102.pin2", placementOnly)}
        />
        {/* D5/pin2 is unused; D1 remains connected as TI requires for output regulation. */}
        <trace from="U27.pin3" to="net.LCD_BACKLIGHT_RETURN_4" />
        <trace from="U27.pin4" to="net.LCD_BACKLIGHT_RETURN_3" />
        <trace from="U27.pin5" to="net.LCD_BACKLIGHT_RETURN_2" />
        <trace from="U27.pin6" to="net.LCD_BACKLIGHT_RETURN_1" />
        <trace
          from="U27.pin7"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U27.pin7", placementOnly)}
        />
        <trace from="U27.pin8" to="net.LCD_BACKLIGHT_OUTPUT" />
        <trace
          name="BL_C2_P"
          from="U27.pin9"
          to="C83.pin1"
          routingPhaseIndex={placementOnly ? undefined : 10}
          thickness={0.3}
        />
        <trace
          name="BL_C2_N"
          from="U27.pin12"
          to="C83.pin2"
          routingPhaseIndex={placementOnly ? undefined : 11}
          thickness={0.3}
        />
        {/* 0.27 mm fits the native 0.270002 mm lands; adjacent centres are 0.499872 mm apart. */}
        <trace
          name="BL_C1_P"
          from="U27.pin10"
          to="C82.pin1"
          routingPhaseIndex={placementOnly ? undefined : 8}
          thickness={0.27}
        />
        <trace
          name="BL_C1_N"
          from="U27.pin11"
          to="C82.pin2"
          routingPhaseIndex={placementOnly ? undefined : 9}
          thickness={0.27}
        />
        <trace from="U27.pin13" to="net.V3V3" />
        <trace
          from="U27.pin14"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U27.pin14", placementOnly)}
        />
        <trace from="U27.pin15" to="net.BACKLIGHT_GATE" />
        <trace from="U27.pin16" to="net.BACKLIGHT_GATE" />
        <trace
          from="U27.pin17"
          to="net.GND"
          width={0.2}
          pcbPath={groundPath("U27.pin17", placementOnly)}
        />
        <trace from="R103.pin1" to="net.MCU_BACKLIGHT_PWM" />
        <trace from="R103.pin2" to="net.BACKLIGHT_GATE" />
        <trace from="R104.pin1" to="net.BACKLIGHT_GATE" />
        <trace
          from="R104.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R104.pin2", placementOnly)}
        />
        <trace from="C84.pin1" to="net.V3V3" />
        <trace
          from="C84.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C84.pin2", placementOnly)}
        />
        <trace from="C85.pin1" to="net.LCD_BACKLIGHT_OUTPUT" />
        <trace
          from="C85.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C85.pin2", placementOnly)}
        />
      </group>
      <ComponentNotes sheet="BacklightSheet" />
    </schematicsheet>
  )
}
