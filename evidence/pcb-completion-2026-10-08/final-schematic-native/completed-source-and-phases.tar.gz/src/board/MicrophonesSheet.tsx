import { ComponentNotes } from "./ComponentNotes"
import { groundPath } from "./GroundPaths"
import { GRM188R71C104KA01D } from "../../imports/GRM188R71C104KA01D/GRM188R71C104KA01D"
import { ICS_43434 } from "../../imports/ICS_43434/ICS_43434"
import { RC0603FR_07100KL } from "../../imports/RC0603FR_07100KL/RC0603FR_07100KL"
import { RC0603FR_0710KL } from "../../imports/RC0603FR_0710KL/RC0603FR_0710KL"
import { A_0603WAF1001T5E } from "../../imports/A_0603WAF1001T5E/A_0603WAF1001T5E"
import { TLV3201AIDBVR } from "../../imports/TLV3201AIDBVR/TLV3201AIDBVR"
import { place } from "./placement"
export function MicrophonesSheet({ placementOnly = false }: { placementOnly?: boolean } = {}) {
  return (
    <schematicsheet
      name="MicrophonesSheet"
      displayName="AI Remote A6 - Dual microphones - prototype"
      sheetSize="A4"
      sheetIndex={10}
    >
      <group name="MicrophonesSheet-group" schLayout={{ layoutMode: "relative" }}>
        <ICS_43434 name="U4" {...place("U4")} schX={-7} schY={2.5} />
        <ICS_43434 name="U5" {...place("U5")} schX={7} schY={4} />
        <GRM188R71C104KA01D name="C80" {...place("C80")} schX={-0.75} schY={9} schRotation={-90} />
        <GRM188R71C104KA01D
          name="C81"
          {...place("C81")}
          schX={0.75}
          schY={9}
          schRotation={-90}
          // Untouched supplier courtyards impose a 1.38 mm lower bound.
          // Keep a finite 2 mm limit; the direct top route measures 1.44 mm.
          maxDecouplingTraceLength={2}
        />
        <TLV3201AIDBVR name="U7" {...place("U7")} schX={0} schY={-5} />
        <RC0603FR_07100KL name="R26" {...place("R26")} schX={-10} schY={-4} schRotation={-90} />
        <A_0603WAF1001T5E name="R27" {...place("R27")} schX={7} schY={-5} />
        <RC0603FR_0710KL name="R29" {...place("R29")} schX={-5} schY={-5} schRotation={-90} />
        <RC0603FR_0710KL name="R30" {...place("R30")} schX={-5} schY={-9} schRotation={-90} />
        <GRM188R71C104KA01D name="C25" {...place("C25")} schX={5} schY={-10} schRotation={-90} />
        <GRM188R71C104KA01D name="C26" {...place("C26")} schX={-10} schY={-9} schRotation={-90} />
        <trace from="U4.pin1" to="net.MIC_WS" />
        <trace
          from="U4.pin3"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U4.pin3", placementOnly)}
        />
        <trace from="U4.pin4" to="net.MIC_BCLK" />
        <trace from="U4.pin5" to="net.VMIC" />
        <trace from="U4.pin6" to="net.MIC_SD" />
        <trace from="U5.pin1" to="net.MIC_WS" />
        <trace
          from="U5.pin3"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U5.pin3", placementOnly)}
        />
        <trace from="U5.pin4" to="net.MIC_BCLK" />
        <trace from="U5.pin5" to="net.VMIC" />
        <trace from="U5.pin6" to="net.MIC_SD" />
        <trace
          from="U4.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U4.pin2", placementOnly)}
        />
        <trace from="U5.pin2" to="net.VMIC" />
        <trace from="C80.pin1" to="net.VMIC" />
        <trace
          from="C80.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C80.pin2", placementOnly)}
        />
        {/* Local bypass loop stays on top copper, joining U5's existing supply
            escape and ground landing without another layer transition. */}
        <trace
          path={["C81.pin1", "U5.pin5", "net.VMIC"]}
          width={0.3}
          pcbPathRelativeTo=".C81 > .pin1"
          pcbPath={placementOnly ? undefined : ["U5.pin5"]}
        />
        <trace
          from="C81.pin2"
          to="net.GND"
          width={0.3}
          // Preflight sees a GND pad 2.15 mm away before the pour exists.
          // Keep a finite branch limit; actual top pour-entry stub is 0.60 mm.
          maxLength={2.5}
          pcbPathRelativeTo=".C81 > .pin2"
          pcbPath={placementOnly ? undefined : [{ x: 1.3, y: 0 }]}
        />
        <trace from="U7.pin1" to="net.MIC_SD_BUFFERED" />
        <trace
          from="U7.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("U7.pin2", placementOnly)}
        />
        <trace from="U7.pin3" to="net.MIC_SD" />
        <trace from="U7.pin4" to="net.MIC_SD_REF" />
        <trace from="U7.pin5" to="net.V3V3" />
        <trace from="R26.pin1" to="net.MIC_SD" />
        <trace
          from="R26.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R26.pin2", placementOnly)}
        />
        <trace from="R27.pin1" to="net.MIC_SD_BUFFERED" />
        <trace from="R27.pin2" to="net.MCU_MIC_SD" />
        <trace from="R29.pin1" to="net.VMIC" />
        <trace from="R29.pin2" to="net.MIC_SD_REF" />
        <trace from="R30.pin1" to="net.MIC_SD_REF" />
        <trace
          from="R30.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("R30.pin2", placementOnly)}
        />
        <trace from="C25.pin1" to="net.V3V3" />
        <trace
          from="C25.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C25.pin2", placementOnly)}
        />
        <trace from="C26.pin1" to="net.MIC_SD_REF" />
        <trace
          from="C26.pin2"
          to="net.GND"
          width={0.3}
          pcbPath={groundPath("C26.pin2", placementOnly)}
        />
      </group>
      <ComponentNotes sheet="MicrophonesSheet" />
    </schematicsheet>
  )
}
